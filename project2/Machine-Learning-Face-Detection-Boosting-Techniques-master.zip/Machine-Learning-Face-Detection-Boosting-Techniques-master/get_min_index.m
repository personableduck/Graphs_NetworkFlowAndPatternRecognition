function min_index = get_min_index(error)
%gets the index of the minimum error value in the array

n=max(size(error));
min_val=error(1);
for i=1:n
    if error(i)<min_val
        
    end
end


end

