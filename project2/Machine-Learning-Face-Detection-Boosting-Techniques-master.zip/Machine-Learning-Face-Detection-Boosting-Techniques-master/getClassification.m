function decision = getClassification(intenssity_diff,j,i)
%return decision if the image patch for the particular feature is a face or
%not by matching the intensity diff of the image against the thresholds of
%the particular feature



end

